
extern "C" {
extern void* dlopen;
}

void* pddd = dlopen;

void* foo()
{
    void* p = dlopen;
    return (void*)dlopen;
}