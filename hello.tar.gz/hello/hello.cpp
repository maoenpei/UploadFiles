
#include <dlfcn.h>

extern void* foo();
extern void* pddd;

void* zzz = (void*)dlopen;

int main(int argc, char** argv)
{
    auto x = &dlopen;

    void* pHandle = dlopen(nullptr, RTLD_LAZY | RTLD_NOLOAD);

    return 0;
}
